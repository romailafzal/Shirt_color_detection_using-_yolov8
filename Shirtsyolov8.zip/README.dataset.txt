# Shirts Detection > 2023-08-30 12:36pm
https://universe.roboflow.com/machine-learning-1-onzg0/shirts-detection

Provided by a Roboflow user
License: CC BY 4.0

